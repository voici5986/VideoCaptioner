import os

# from configs import subtitle_config
#
# os.environ['OPENAI_BASE_URL'] = subtitle_config.OPENAI_BASE_URL
# os.environ['OPENAI_API_KEY'] = subtitle_config.OPENAI_API_KEY
# MODEL = subtitle_config.MODEL
